///@system  Dstar V10 api demo
///@file    UdpClient.h
///@author  Hao Lin 2021-01-20

#include "UdpClient.h"

TUdpClient::TUdpClient()
    : m_Socket(-1)
{
    
}

TUdpClient::~TUdpClient()
{
    Close();
}


int TUdpClient::Init(const char *toip, const unsigned short toport)
{
    //检查当前socket
    if (-1 != m_Socket)
        return 1;

    //创建socket, 无效则返回
    int s = ::socket(AF_INET,SOCK_DGRAM,0);
    if (-1 == s)
        return 2;

    //设置非阻塞
    int x(fcntl(s, F_GETFL, 0));
    fcntl(s, F_SETFL, x | O_NONBLOCK);


    unsigned value = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &value, sizeof(value));

    //设置阻塞
    fcntl(s, F_SETFL, x);

    m_Socket = s;

    memset(&m_ToAddr, 0, sizeof(sockaddr_in));
    m_ToAddr.sin_family = AF_INET;
    m_ToAddr.sin_addr.s_addr = inet_addr(toip);
    m_ToAddr.sin_port = htons(toport);
    return 0;
}

void TUdpClient::Close()
{
    if (-1 == m_Socket)
        return;

    m_Socket = -1;
}

int TUdpClient::Send(const char *buf, const int len)
{
    int ret = ::sendto(m_Socket, buf, len, 0, (struct sockaddr*)&m_ToAddr, sizeof(m_ToAddr));
    if (len != ret)
    {
        return 1;
    }

    return 0;
}

