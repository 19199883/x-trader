///@system  Dstar V10 api demo
///@file    main.cpp
///@author  Hao Lin 2021-01-20

#include <stdio.h>
#include <unistd.h>

#include "ApiClient.h"
#include "UdpClient.h"

char    front_ip[] = "127.0.0.1";

int     front_port = 6668;                  
int     udp_port = 6666;                    //udp报单端口

char    account[] = "6003";
char    passwd[] = "123456";
char    app_id[] = "esunny_epolestar_9.0";
char    license_no[] = "esunny_epolestar";

int     contindex = 0;
char    contractno[] = "CF903";
int     option_contindex = 24;
char    option_contractno[] = "CF001C14600";
char    direct = DSTAR_API_DIRECT_BUY;
char    offset = DSTAR_API_OFFSET_OPEN;
int     qty = 1;
int     min_qty = 0;
double  price = 15000;
int     client_reqid = 1;
int     reference = 1;

TUdpClient g_UdpClient;
ApiClient g_ApiClient;

void UdpAuth();
void FillHead(DstarApiHead *head, DstarApiProtocolCodeType protocol, int framesize);
void InsertOrder();
void InsertBatchOrder();
void InsertEnquiry();
void InsertOffer(char *enquiryno);
void InsertBatchOffer();
void InsertOptionExec();

int main(int argc, char *argv[])
{
    //创建API
    if (g_ApiClient.CreateApi() != 0 )
    {
        return 1;
    }
    
    //UDP初始化
    if (g_UdpClient.Init(front_ip, udp_port) != 0)
    {
        printf("udp client init failed\n");
        return 1;
    }
    
    //设置信息
    g_ApiClient.SetAddress(front_ip, front_port);
    g_ApiClient.SetUser(account, passwd, app_id, license_no);
    
    //初始化
    int ret = g_ApiClient.Init();
    if(ret < 0)
    {
        printf("Api init failed, ret=%d\n", ret);
        return 1;
    }

    //等待API初始化就绪
    while (!g_ApiClient.IsReady())
    {
        sleep(1);
    }

    //UDP认证
    UdpAuth();

    //等待认证就绪
    while (!g_ApiClient.IsUdpAuth())
    {
        sleep(1);
    }
    
    //报单
    InsertOrder();
    
    sleep(10);
    
    //批量报单
    InsertBatchOrder();
    
    sleep(10);
    
    //询价
    InsertEnquiry();
    
    sleep(10);
    
    //报价
    InsertOffer(0);
    
    sleep(10);
    
    //批量报价
    InsertBatchOffer();
    
    //行权
    InsertOptionExec();

    while(1)
    {
        sleep(15);
    }

    return 0;
}

void FillHead(DstarApiHead *head, DstarApiProtocolCodeType protocol, int nFieldCount, int nFieldSize)
{
    head->FrameFlag = DSTAR_API_HEAD_FLAG;
    head->ProtocolCode = protocol;
    head->Version = DSTAR_API_PROTOCOL_VERSION;
    head->FieldCount = nFieldCount;
    head->FieldSize = nFieldSize;
}

//认证
void UdpAuth()
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_UdpAuth, 1, sizeof(DstarApiReqUdpAuthField));

    DstarApiReqUdpAuthField *req = (DstarApiReqUdpAuthField *) &sendbuf[sizeof(DstarApiHead)];
    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ReqIdMode = DSTAR_API_REQIDMODE_NOCHECK;

    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//报单
void InsertOrder()
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OrderInsert, 1, sizeof(DstarApiReqOrderInsertField));

    DstarApiReqOrderInsertField *req = (DstarApiReqOrderInsertField *) &sendbuf[sizeof(DstarApiHead)];

    req->Direct = direct;
    req->Offset = offset;
    req->Hedge = DSTAR_API_HEDGE_SPECULATE;
    req->OrderType = DSTAR_API_ORDERTYPE_LIMIT;
    req->ValidType = DSTAR_API_VALID_GFD;
    req->Reference = reference++;
    req->SeatIndex = 1;
    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ClientReqId = client_reqid++;
    req->ContractIndex = contindex;
    strncpy(req->ContractNo, contractno, sizeof(DstarApiContractNoType) - 1);
    req->OrderQty = qty;
    req->OrderPrice = price;
    req->MinQty = min_qty;
    
    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//批量报单
void InsertBatchOrder()
{
    char sendbuf[2048] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OrderInsert, 8, sizeof(DstarApiReqOrderInsertField));

    for (int i = 0; i < 8; i++)
    {
        DstarApiReqOrderInsertField *req = (DstarApiReqOrderInsertField *) &sendbuf[sizeof(DstarApiHead) + i * sizeof(DstarApiReqOrderInsertField)];

        req->Direct = direct;
        req->Offset = offset;
        req->Hedge = DSTAR_API_HEDGE_SPECULATE;
        req->OrderType = DSTAR_API_ORDERTYPE_LIMIT;
        req->ValidType = DSTAR_API_VALID_GFD;
        req->Reference = reference++;
        req->SeatIndex = 1;
        req->AccountIndex = g_ApiClient.GetAccountIndex();
        req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
        req->ClientReqId = client_reqid++;
        req->ContractIndex = contindex;
        strncpy(req->ContractNo, contractno, sizeof(DstarApiContractNoType) - 1);
        req->OrderQty = qty;
        req->OrderPrice = price;
        req->MinQty = min_qty;
    }

    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//询价
void InsertEnquiry()
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OrderInsert, 1, sizeof(DstarApiReqOrderInsertField));

    DstarApiReqOrderInsertField *req = (DstarApiReqOrderInsertField *) &sendbuf[sizeof(DstarApiHead)];

    req->Direct = DSTAR_API_DIRECT_ALL;
    req->OrderType = DSTAR_API_ORDERTYPE_ENQUIRY;
    req->Reference = reference++;
    req->SeatIndex = 1;
    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ClientReqId = client_reqid++;
    req->ContractIndex = contindex;
    strncpy(req->ContractNo, contractno, sizeof(DstarApiContractNoType) - 1);
    
    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//行权
void InsertOptionExec()
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OrderInsert, 1, sizeof(DstarApiReqOrderInsertField));

    DstarApiReqOrderInsertField *req = (DstarApiReqOrderInsertField *) &sendbuf[sizeof(DstarApiHead)];

    req->OrderType = DSTAR_API_ORDERTYPE_EXECUTE;
    req->Reference = reference++;
    req->SeatIndex = 1;
    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ClientReqId = client_reqid++;
    req->ContractIndex = option_contindex;
    strncpy(req->ContractNo, option_contractno, sizeof(DstarApiContractNoType) - 1);
    req->OrderQty = qty;
    
    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//报价
void InsertOffer(char *enquiryno)
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OfferInsert, 1, sizeof(DstarApiReqOfferInsertField));
    
    DstarApiReqOfferInsertField *req = (DstarApiReqOfferInsertField *) &sendbuf[sizeof(DstarApiHead)];
    
    req->BuyOffset = offset;
    req->SellOffset = offset;
    req->SeatIndex = 1;
    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ClientReqId = client_reqid++;
    req->ContractIndex = contindex;
    strncpy(req->ContractNo, contractno, sizeof(DstarApiContractNoType) - 1);
    req->OrderQty = qty;
    req->BuyPrice = price;
    req->SellPrice = price;
    req->Reference = reference++;
    //询价号
    if (enquiryno != NULL && strlen(enquiryno) > 0)
    {
        strncpy(req->EnquiryNo, enquiryno, sizeof(DstarApiSystemNoType) - 1);
    }

    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

//批量报价单
void InsertBatchOffer()
{
    char sendbuf[2048] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OfferInsert, 15, sizeof(DstarApiReqOfferInsertField));

    for (int i = 0; i < 15; i++)
    {
        DstarApiReqOfferInsertField *req = (DstarApiReqOfferInsertField *) &sendbuf[sizeof(DstarApiHead) + i * sizeof(DstarApiReqOfferInsertField)];

        req->BuyOffset = offset;
        req->SellOffset = offset;
        req->SeatIndex = 1;
        req->AccountIndex = g_ApiClient.GetAccountIndex();
        req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
        req->ClientReqId = client_reqid++;
        req->ContractIndex = contindex;
        strncpy(req->ContractNo, contractno, sizeof(DstarApiContractNoType) - 1);
        req->OrderQty = qty;
        req->BuyPrice = price;
        req->SellPrice = price;
        req->Reference = reference++;
        //询价号
        //strncpy(req->EnquiryNo, EnquiryNo, sizeof(DstarApiSystemNoType) - 1);
    }

    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}

int DeleteOrder(char *orderno)
{
    char sendbuf[1024] = {0};
    DstarApiHead *head = (DstarApiHead *)sendbuf;
    FillHead(head, CMD_API_Req_OrderDelete, 1, sizeof(DstarApiReqOrderDeleteField));

    DstarApiReqOrderDeleteField *req = (DstarApiReqOrderDeleteField *) &sendbuf[sizeof(DstarApiHead)];

    req->AccountIndex = g_ApiClient.GetAccountIndex();
    req->UdpAuthCode = g_ApiClient.GetUdpAuthCode();
    req->ClientReqId = client_reqid++;
    req->Reference = reference++;
    req->SeatIndex = 0;
    strncpy(req->OrderNo, orderno, sizeof(DstarApiOrderNoType) - 1);
    
    g_UdpClient.Send(sendbuf, sizeof(DstarApiHead) + head->FieldCount * head->FieldSize);
}
