///@system  Dstar V10 api demo
///@file    ApiClient.cpp
///@author  Hao Lin 2021-01-20


#include "ApiClient.h"


ApiClient::ApiClient()
    : m_pApi(NULL)
    , m_bReady(false)
    , m_bUdpAuth(false)
{

}

ApiClient::~ApiClient()
{
    FreeDstarTradeApi(m_pApi);
}

void ApiClient::SetAddress(const char *ip, int port)
{
    strncpy(m_FrontIp, ip, sizeof(m_FrontIp) - 1);
    m_FrontPort = port;
}

void ApiClient::SetUser(const char *account, char *passwd, char *appid, char *licenseno)
{
    strncpy(m_LoginReq.AccountNo, account, sizeof(DstarApiAccountNoType) - 1);
    strncpy(m_LoginReq.Password, passwd, sizeof(DstarApiPasswdType) - 1);
    strncpy(m_LoginReq.AppId, appid, sizeof(DstarApiAppIdType) - 1);
    strncpy(m_LoginReq.LicenseNo, licenseno, sizeof(DstarApiLicenseNoType) - 1);
}

int ApiClient::CreateApi()
{
    m_pApi = CreateDstarTradeApi();
    if (!m_pApi)
    {
        printf("Create Api Failed\n");
        return 1;
    }
    else
    {
        printf("Create Api Successfully, version:%s\n", m_pApi->GetApiVersion());
    }

    return 0;
}

int ApiClient::Init()
{
    if (!m_pApi)
    {
        return -1;
    }
    m_pApi->RegisterSpi(this);
    m_pApi->RegisterFrontAddress(m_FrontIp, m_FrontPort);
    char log_path[] = "/home/esunny/apidemo/";
    m_pApi->SetApiLogPath(log_path);
    m_pApi->SetLoginInfo(&m_LoginReq);
    m_pApi->SetCpuId(0, 1);
    m_pApi->SetSubscribeStartId(-1);
    int ret = SubmitSystemInfo();
    if (ret != 0)
    {
        return ret;
    }
    
    return m_pApi->Init(DSTAR_API_INIT_QUERY);
}

bool ApiClient::IsReady()
{
    return m_bReady;
}

bool ApiClient::IsUdpAuth()
{
    return m_bUdpAuth;
}

DstarApiAccountIndexType ApiClient::GetAccountIndex()
{
    return m_LoginInfo.AccountIndex;
}

DstarApiAuthCodeType ApiClient::GetUdpAuthCode()
{
    return m_LoginInfo.UdpAuthCode;
}

void ApiClient::OnFrontDisconnected()
{
    printf("OnFrontDisconnected\n");
}

void ApiClient::OnRspError(DstarApiErrorCodeType nErrorCode)
{
    printf("OnRspError:%u\n", nErrorCode);
}

void ApiClient::OnApiReady(const DstarApiSerialIdType nSerialId)
{
    printf("OnApiReady, serial:%llu\n", nSerialId);

    m_bReady = true;
}

void ApiClient::OnRspUserLogin(const DstarApiRspLoginField *pLoginRsp)
{
    m_LoginInfo = *pLoginRsp;
    printf("OnRspUserLogin user:%s index:%u error:%u authcode:%u\n",
           m_LoginInfo.AccountNo, m_LoginInfo.AccountIndex, m_LoginInfo.ErrorCode, m_LoginInfo.UdpAuthCode);
}

void ApiClient::OnRspSubmitInfo(const DstarApiRspSubmitInfoField *pRspSubmitInfo)
{
    printf("OnRspSubmitInfo user:%s error:%u \n",
           pRspSubmitInfo->AccountNo, pRspSubmitInfo->ErrorCode);
}

void ApiClient::OnRtnOrder(const DstarApiOrderField *pOrder)
{
    printf("OnRtnOrder OrderNo:%s err:%u SeatIndex:%d\n", pOrder->OrderNo, pOrder->ErrCode, pOrder->SeatIndex);
}

void ApiClient::OnRtnOffer(const DstarApiOfferField *pOffer)
{
    printf("OnRtnOffer OrderNo:%s err:%u\n", pOffer->OrderNo, pOffer->ErrCode);
}

void ApiClient::OnRtnMatch(const DstarApiMatchField *pMatch)
{
    printf("OnRtnMatch MatchNo:%s\n", pMatch->MatchNo);
}

void ApiClient::OnRtnEnquiry(const DstarApiEnquiryField *pEnquiry)
{
    printf("OnRtnEnquiry contract:%s direct:%c EnquiryNo:%s\n",
           pEnquiry->ContractNo, pEnquiry->Direct, pEnquiry->EnquiryNo);
}

void ApiClient::OnRspSeat(const DstarApiSeatField *pSeatInfo)
{
    printf("OnRspSeat seatindex:%d exchange:%c seatno:%s\n", pSeatInfo->SeatIndex, pSeatInfo->Exchange, pSeatInfo->SeatNo);
}

void ApiClient::OnRspContract(const DstarApiContractField *pContract)
{
    printf("OnRspContract ContractIndex:%u ContractNo:%s\n", pContract->ContractIndex, pContract->ContractNo);
}

void ApiClient::OnRspPosition(const DstarApiPositionField *pPosition)
{
    printf("OnRspPosition,AccountNo:%s, ContractNo:%s, SerialId:%llu\n",
            pPosition->AccountNo, pPosition->ContractNo, pPosition->SerialId);
}

void ApiClient::OnRspFund(const DstarApiFundField *pFund)
{
    printf("OnRspFund AccountNo:%s, PreEquity:%f, Equity:%f, Avail:%f, Fee:%f, Margin:%f, "
            "FrozenMargin:%f, Premium:%f, CloseProfit:%f, PositionProfit:%f, CashIn:%f, CashOut:%f\n",
            pFund->AccountNo, pFund->PreEquity, pFund->Equity, pFund->Avail,
            pFund->Fee, pFund->Margin, pFund->FrozenMargin, pFund->Premium,
            pFund->CloseProfit, pFund->PositionProfit, pFund->CashIn, pFund->CashOut);
}

void ApiClient::OnRspOrder(const DstarApiOrderField *pOrder)
{
    printf("OnRspOrder OrderNo:%s, OrderPrice:%f, OrderQty:%d, MinQty:%d, MatchQty:%d, Direct:%c, Offset:%c, Hedge:%c, OrderType:%c, "
            "ValidType:%c, OrderState:%c, ErrCode:%d, OrderNo:%s, OrderLocalNo:%s, SystemNo:%s, ExchInsertTime:%s, "
            "SerialId:%llu, FrozenMargin:%f, AccountNo:%s, Ref:%d, SeatIndex:%d\n",
            pOrder->ContractNo, pOrder->OrderPrice, pOrder->OrderQty, pOrder->MinQty,
            pOrder->MatchQty, pOrder->Direct, pOrder->Offset, pOrder->Hedge,
            pOrder->OrderType, pOrder->ValidType, pOrder->OrderState, pOrder->ErrCode,
            pOrder->OrderNo, pOrder->OrderLocalNo, pOrder->SystemNo, pOrder->ExchInsertTime,
            pOrder->SerialId, pOrder->FrozenMargin, pOrder->AccountNo, pOrder->Reference, pOrder->SeatIndex);
}

void ApiClient::OnRspOffer(const DstarApiOfferField *pOffer)
{
    printf("OnRspOffer BuyOffset:%c, SellOffset:%c, ContractNo:%s, OrderQty:%d, ErrCode:%d, "
            "BuyPrice:%f, SellPrice:%f, OrderNo:%s, "
            "OrderLocalNo:%s, SystemNo:%s, QueryNo:%s, OrderState:%c, SerialId:%d, FrozenMargin:%f, "
            "AccountNo:%s, SeatIndex:%d\n",
            pOffer->BuyOffset, pOffer->SellOffset, pOffer->ContractNo,
            pOffer->OrderQty, pOffer->ErrCode, pOffer->BuyPrice, pOffer->SellPrice,
            pOffer->OrderNo, pOffer->OrderLocalNo, pOffer->SystemNo,
            pOffer->EnquiryNo, pOffer->OrderState, pOffer->SerialId, pOffer->FrozenMargin,
            pOffer->AccountNo, pOffer->SeatIndex);
}

void ApiClient::OnRspMatch(const DstarApiMatchField *pMatch)
{
    printf("OnRspMatch contract:%s qty:%d price:%f offset:%c direct:%c hedge:%c time:%s orderno:%s "
            "matchno:%s systemno:%s serial:%llu fee:%f margin:%f frozen:%f premium:%f closeprofit:%f "
            "acccount:%s reference:%d ordertype:%c\n",
            pMatch->ContractNo, pMatch->MatchQty, pMatch->MatchPrice, pMatch->Offset,
            pMatch->Direct, pMatch->Hedge, pMatch->MatchTime,
            pMatch->OrderNo, pMatch->MatchNo, pMatch->SystemNo, pMatch->SerialId,
            pMatch->Fee, pMatch->Margin, pMatch->FrozenMargin, pMatch->Premium,
            pMatch->CloseProfit, pMatch->AccountNo, pMatch->Reference, pMatch->OrderType);
}

void ApiClient::OnRspCashInOut(const DstarApiCashInOutField *pCashInOut)
{
    printf("OnRspCashInOut SerialId:%llu CashInOutType:%c CashInOutValue:%f AccountNo:%s OperateTime:%s\n",
            pCashInOut->SerialId, pCashInOut->CashInOutType, pCashInOut->CashInOutValue, pCashInOut->AccountNo,
            pCashInOut->OperateTime);
}

void ApiClient::OnRspUdpAuth(const DstarApiRspUdpAuthField *pRspUdpAuth)
{
    if (pRspUdpAuth->ErrorCode == 0)
    {
        m_bUdpAuth = true;
    }
    printf("OnRspUdpAuth AccountIndex:%d UdpAuthCode:%u ErrorCode:%u\n",
           pRspUdpAuth->AccountIndex, pRspUdpAuth->UdpAuthCode, pRspUdpAuth->ErrorCode);
}

void ApiClient::OnRspOrderInsert(const DstarApiRspOrderInsertField *pOrderInsert)
{
    printf("OnRspOrderInsert ClientReqId:%d SeatIndex:%d OrderNo:%s ErrCode:%u MaxClientReqId:%u\n",
            pOrderInsert->ClientReqId, pOrderInsert->SeatIndex, pOrderInsert->OrderNo, pOrderInsert->ErrCode, pOrderInsert->MaxClientReqId);
}

void ApiClient::OnRspOfferInsert(const DstarApiRspOfferInsertField *pOfferInsert)
{
    printf("OnRspOfferInsert ClientReqId:%d SeatIndex:%u OrderNo:%s ErrCode:%u\n",
            pOfferInsert->ClientReqId, pOfferInsert->SeatIndex, pOfferInsert->OrderNo, pOfferInsert->ErrCode);
}

void ApiClient::OnRspLastReqId(const DstaApiRspLastReqIdField *pLastReqId)
{
    printf("OnRspLastReqId ClientReqId:%d \n", pLastReqId->LastClientReqId);
}

void ApiClient::OnRspOrderDelete(const DstarApiRspOrderDeleteField *pOrderDelete)
{
    printf("OnRspOrderDelete AccountNo:%s ClientReqId:%d MaxClientReqId:%d SeatIndex:%d OrderNo:%s ErrCode:%d Reference:%d\n",
            pOrderDelete->AccountNo, pOrderDelete->ClientReqId, pOrderDelete->MaxClientReqId, pOrderDelete->SeatIndex,
            pOrderDelete->OrderNo, pOrderDelete->ErrCode, pOrderDelete->Reference);
}

void ApiClient::OnRtnCashInOut(const DstarApiCashInOutField *pCashInOut)
{
    printf("OnRtnCashInOut\n");
}

int ApiClient::SubmitSystemInfo()
{
    char systeminfo[1024] = {0};
    int nLen = 1024;
    unsigned int nVersion = 0;
    int ret = m_pApi->GetSystemInfo(systeminfo, &nLen, &nVersion);
    printf("GetSystemInfo, ret:%d, len:%d, version:%d\n", ret, nLen, nVersion);
    if (ret != 0)
    {
        return ret;
    }
    
    DstarApiSubmitInfoField pSubmitInfo = {0};
    strncpy(pSubmitInfo.AccountNo, m_LoginReq.AccountNo, sizeof(DstarApiAccountNoType) - 1);
    pSubmitInfo.AuthType = DSTAR_API_AUTHTYPE_DIRECT;
    pSubmitInfo.AuthKeyVersion = nVersion;
    memcpy(pSubmitInfo.SystemInfo, systeminfo, nLen);
    strncpy(pSubmitInfo.LicenseNo, "esunny_epolestar", sizeof(DstarApiLicenseNoType) - 1);
    strncpy(pSubmitInfo.ClientAppId, "esunny_epolestar_9.0", sizeof(DstarApiAppIdType) - 1);
    
    m_pApi->SetSubmitInfo(&pSubmitInfo);
    
    return ret;
}

