///@system  Dstar V10 api demo
///@file    UdpClient.cpp
///@author  Hao Lin 2021-01-20

#ifndef TUDPCLIENT_H
#define TUDPCLIENT_H

#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/poll.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <string.h>


class TUdpClient
{
public:
    TUdpClient();
    ~TUdpClient();

    int  Init(const char *toip, const unsigned short toport);
    void Close();

    int Send(const char* buf, const int len);//返回0为成功

private:
    int         m_Socket;
    sockaddr_in m_ToAddr;
};

#endif // TUDPCLIENT_H
